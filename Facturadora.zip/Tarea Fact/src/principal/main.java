package principal;

import javax.swing.JOptionPane;

public class main {
	public static void main(String[] args) {
	
		fact pro = new fact();
		pro.menu();
	}
}